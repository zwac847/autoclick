package com.mobilclicker.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * Asıl iş burada: kısayol tuşunu dinler, fare konumunu izler ve
 * ayarlanan hızda ekrana dokunuş gönderir.
 */
public class ClickService extends AccessibilityService {

    public static volatile ClickService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();

    private Prefs prefs;
    private WindowManager wm;
    private TextView badge;
    private View pickView;

    private boolean running;
    private int gen; // eski döngüleri geçersiz kılmak için sayaç
    private long clicks;
    private long startedAt;

    private float mouseX = -1f;
    private float mouseY = -1f;
    private boolean warnedNoMouse;

    // Başlarken ayarların anlık görüntüsü
    private int mode;
    private long intervalMs;
    private long jitterMs;
    private long holdMs;
    private long maxClicks;
    private float fixedX;
    private float fixedY;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        prefs = new Prefs(this);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        // Fare takibi varsayılan KAPALI: açıkken bazı telefonlarda fareyi kilitliyor.
        if (prefs.mouseTrack()) applyMouseTracking();
    }

    /** Fare takibini ayara göre açar/kapatır (Android 14+). */
    public void applyMouseTracking() {
        if (Build.VERSION.SDK_INT < 34) return;
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info == null) return;
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
            boolean on = prefs != null && prefs.mouseTrack();
            info.setMotionEventSources(on ? InputDevice.SOURCE_MOUSE : 0);
            setServiceInfo(info);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        stopClicking(false);
        removePick();
        hideBadge();
        instance = null;
        return super.onUnbind(intent);
    }

    /** Fare imlecinin ekrandaki son konumunu takip eder (Android 14+). */
    public void onMotionEvent(MotionEvent event) {
        try {
            if (event != null && event.isFromSource(InputDevice.SOURCE_MOUSE)) {
                mouseX = event.getRawX();
                mouseY = event.getRawY();
            }
        } catch (Throwable ignored) {
        }
    }

    /** Kısayol tuşu: her uygulamanın üstünde çalışır. */
    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        if (prefs == null) return false;
        if (e.getKeyCode() != prefs.hotkey()) return false;
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            toggle(0);
        }
        return true; // tuşu yut, başka uygulamaya gitmesin
    }

    // ---------------------------------------------------------------- kontrol

    public boolean isRunning() {
        return running;
    }

    public void toggle(long extraDelayMs) {
        if (running) stopClicking(true);
        else startClicking(extraDelayMs);
    }

    public void startClicking(long extraDelayMs) {
        if (running) return;
        if (prefs == null) prefs = new Prefs(this);

        mode = prefs.mode();
        intervalMs = Math.max(1, prefs.interval());
        jitterMs = Math.max(0, prefs.jitter());
        holdMs = Math.max(1, prefs.hold());
        maxClicks = Math.max(0, prefs.max());
        fixedX = prefs.fixedX();
        fixedY = prefs.fixedY();

        if (mode == Prefs.MODE_MOUSE && Build.VERSION.SDK_INT < 34) {
            toast("Fare takibi Android 14+ ister. Sabit nokta modunu kullan.");
            return;
        }
        if (mode == Prefs.MODE_MOUSE && !prefs.mouseTrack()) {
            toast("Fare takibi kapalı. Ayarlardan aç veya sabit nokta seç.");
            return;
        }
        if (mode == Prefs.MODE_FIXED && fixedX < 0) {
            toast("Önce uygulamadan sabit nokta seç.");
            return;
        }

        running = true;
        clicks = 0;
        startedAt = SystemClock.uptimeMillis();
        warnedNoMouse = false;
        gen++;

        showBadge();
        handler.removeCallbacks(uiUpdate);
        handler.post(uiUpdate);

        long wait = Math.max(0, prefs.delay()) + Math.max(0, extraDelayMs);
        handler.postDelayed(makeTick(gen), wait);
        toast(wait >= 1000 ? "▶ " + (wait / 1000) + " sn sonra başlıyor" : "▶ Başladı");
    }

    public void stopClicking(boolean showToast) {
        if (!running) return;
        running = false;
        gen++;
        handler.removeCallbacksAndMessages(null);
        hideBadge();
        if (showToast) toast("■ Durdu — " + clicks + " tık");
    }

    // ---------------------------------------------------------------- tıklama döngüsü

    private Runnable makeTick(final int g) {
        return new Runnable() {
            @Override
            public void run() {
                doClick(g);
            }
        };
    }

    private void doClick(final int g) {
        if (!running || g != gen) return;

        if (maxClicks > 0 && clicks >= maxClicks) {
            stopClicking(true);
            return;
        }

        float x;
        float y;
        if (mode == Prefs.MODE_FIXED) {
            x = fixedX;
            y = fixedY;
        } else {
            if (mouseX < 0) {
                if (!warnedNoMouse) {
                    warnedNoMouse = true;
                    toast("Fare konumu henüz alınamadı. Fareyi biraz oynat.");
                }
                scheduleNext(g, SystemClock.uptimeMillis());
                return;
            }
            x = mouseX;
            y = mouseY;
        }

        final long t0 = SystemClock.uptimeMillis();
        boolean ok;
        try {
            Path path = new Path();
            path.moveTo(x, y);
            GestureDescription gd = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, Math.max(1, holdMs)))
                    .build();
            ok = dispatchGesture(gd, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gestureDescription) {
                    if (running && g == gen) {
                        clicks++;
                        scheduleNext(g, t0);
                    }
                }

                @Override
                public void onCancelled(GestureDescription gestureDescription) {
                    if (running && g == gen) {
                        scheduleNext(g, t0);
                    }
                }
            }, null);
        } catch (Throwable t) {
            ok = false;
        }
        if (!ok) scheduleNext(g, t0);
    }

    private void scheduleNext(int g, long t0) {
        if (!running || g != gen) return;
        long iv = intervalMs;
        if (jitterMs > 0) {
            iv += (long) ((rnd.nextDouble() * 2 - 1) * jitterMs);
        }
        if (iv < 1) iv = 1;
        long wait = Math.max(0, iv - (SystemClock.uptimeMillis() - t0));
        handler.postDelayed(makeTick(g), wait);
    }

    // ---------------------------------------------------------------- rozet

    private final Runnable uiUpdate = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            if (badge != null) {
                long sec = Math.max(1, (SystemClock.uptimeMillis() - startedAt) / 1000);
                badge.setText("● AKTİF   " + clicks + " tık   " + (clicks / sec) + "/sn");
            }
            handler.postDelayed(this, 250);
        }
    };

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showBadge() {
        if (badge != null || prefs == null || !prefs.badge()) return;
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setText("● AKTİF");
        t.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xCC1FA463);
        g.setCornerRadius(dp(20));
        t.setBackground(g);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(12);
        lp.y = dp(60);
        try {
            wm.addView(t, lp);
            badge = t;
        } catch (Throwable ignored) {
        }
    }

    private void hideBadge() {
        if (badge == null) return;
        try {
            wm.removeView(badge);
        } catch (Throwable ignored) {
        }
        badge = null;
    }

    // ---------------------------------------------------------------- sabit nokta seçme

    /** Ekranı örten bir katman açar; ilk dokunuş / fare tıkı nokta olarak kaydedilir. */
    public void beginPick(final Runnable done) {
        if (pickView != null || wm == null) return;
        TextView v = new TextView(this);
        v.setText("Tıklanacak noktayı seç\n(dokun veya fareyle tıkla)");
        v.setTextColor(Color.WHITE);
        v.setTextSize(18);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(0x99000000);
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent ev) {
                if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    float x = ev.getRawX();
                    float y = ev.getRawY();
                    prefs.setFixed(x, y);
                    removePick();
                    toast("Nokta kaydedildi: " + (int) x + ", " + (int) y);
                    if (done != null) done.run();
                }
                return true;
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        try {
            wm.addView(v, lp);
            pickView = v;
        } catch (Throwable ignored) {
        }
    }

    private void removePick() {
        if (pickView == null) return;
        try {
            wm.removeView(pickView);
        } catch (Throwable ignored) {
        }
        pickView = null;
    }

    private void toast(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
    }
}
